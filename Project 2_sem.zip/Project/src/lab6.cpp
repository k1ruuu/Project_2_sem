#include "lab6.hpp"

ofstream Logger::m_out;
LogLevel Logger::m_level;