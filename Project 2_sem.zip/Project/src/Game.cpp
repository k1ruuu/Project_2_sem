#include <SFML/Graphics.hpp>
#include <iostream>
#include "lab6.hpp"
#include "Game.hpp"
#include <vector>
#include <list>

namespace ss {

	const int H = 20;
	const int W = 50;

	String Map[H] = {
	"                                                  ",
	"                                                  ",
	"                                                  ",
	"                                                  ",
	"                                                  ",
	"                                                  ",
	"                                                  ",
	"                                                  ",
	"                                        ah        ",
	"                                       zxc        ",
	"                                                  ",
	"                                                  ",
	"                                o     o           ",
	"                                zxxxxxc           ",
	"                             h                    ",
	"                           i zxc                  ",
	"g  >  g            o   g  g      o                ",
	"rttttttttttttttttttttttttttttttttttttttttttttttttq",
	"mnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnnw",
	"lkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkkke"
	};
	float offsetX = 0;
	float offsetY = 0;

	Life::Life()
	{
		image.loadFromFile("heart.png");
		t.loadFromImage(image);

		s1.setTexture(t);
		s1.setTextureRect(IntRect(0, 0, 32, 32));
		s1.setPosition(32, 32);

		s2.setTexture(t);
		s2.setTextureRect(IntRect(0, 0, 32, 32));
		s2.setPosition(64, 32);

		s3.setTexture(t);
		s3.setTextureRect(IntRect(0, 0, 32, 32));
		s3.setPosition(96, 32);
	}


	void Life::draw(RenderWindow& window)
	{
		Vector2f center = window.getView().getCenter();
		Vector2f size = window.getView().getSize();

		s1.setPosition(center.x - size.x / 2 + 10 + 32, center.y - size.y / 2 + 10 + 32);
		s2.setPosition(center.x - size.x / 2 + 10 + 64, center.y - size.y / 2 + 10 + 32);
		s3.setPosition(center.x - size.x / 2 + 10 + 96, center.y - size.y / 2 + 10 + 32);

		window.draw(s1);
		window.draw(s2);
		window.draw(s3);
	}

	void Enemy::set(Texture& image, int x, int y)
	{
		sprite1.setTexture(image);
		sprite1.setTextureRect(IntRect(0, 18, 16, 25));
		rect1 = FloatRect(x, y, 32, 32);

		dx = dy = 0.1;
		currentFrame1 = 0;
		life = true;
	}

	void Enemy::update(float time)
	{
		rect1.left += dx;

		Collision();


		/*currentFrame1 += time * 0.005;
		if (currentFrame1 > 2) currentFrame1 -= 2;*/

		/*sprite1.setTextureRect(IntRect(18 * int(currentFrame1), 0, 16, 16));*/
		if (!life) sprite1.setTextureRect(IntRect(0, 0, 0, 0));


		sprite1.setPosition(rect1.left - offsetX, rect1.top - offsetY);

	}

	void Enemy::Collision() {

		for (int i = rect1.top / 32; i < (rect1.top + rect1.height) / 32; i++)
			for (int j = rect1.left / 32; j < (rect1.left + rect1.width) / 32; j++)
				if (Map[i][j] == 'z' || Map[i][j] == 'x' || Map[i][j] == 'r' || Map[i][j] == 't' || Map[i][j] == 'o' || Map[i][j] == 'c' || Map[i][j] == 'q' || Map[i][j] == 'w' || Map[i][j] == 'e')
				{
					if (dx > 0)
					{
						rect1.left = j * 32 - rect1.width; dx *= -1;
					}
					else if (dx < 0)
					{
						rect1.left = j * 32 + 32;  dx *= -1;
					}

					if (dy > 0) {
						rect1.top = i * 32 - rect1.height;
						dy = 0;
					}
					else if (dy < 0) {
						rect1.top = i * 32 + 32;
						dy *= -1;
					}

				}
	}

	void pepe::set(Texture& image, int x, int y) {
		sprite1.setTexture(image);
		sprite1.setTextureRect(IntRect(0, 0, 32, 32));
		rect1 = FloatRect(x, y, 32, 32);

		dx = dy = 0.1;
		currentFrame1 = 0;
		life = true;
	}

	void pepe::update(float time)
	{
		rect1.left += dx;
		Collision();

		rect1.top += dy * time;
		Collision();

		/*currentFrame1 += time * 0.005;
		if (currentFrame1 > 2) currentFrame1 -= 2;*/

		//sprite1.setTextureRect(IntRect(18 * int(currentFrame1), 0, 16, 16));
		if (!life) sprite1.setTextureRect(IntRect(0, 0, 0, 0));


		sprite1.setPosition(rect1.left - offsetX, rect1.top - offsetY);

	}

	void pepe::Collision() {

		for (int i = rect1.top / 32; i < (rect1.top + rect1.height) / 32; i++)
			for (int j = rect1.left / 32; j < (rect1.left + rect1.width) / 32; j++)
				if (Map[i][j] == 'z' || Map[i][j] == 'x' || Map[i][j] == 'r' || Map[i][j] == 't' || Map[i][j] == 'o' || Map[i][j] == 'c' || Map[i][j] == 'q' || Map[i][j] == 'w' || Map[i][j] == 'e')
				{
					if (dx > 0)
					{
						rect1.left = j * 32 - rect1.width; dx *= -1;
					}
					else if (dx < 0)
					{
						rect1.left = j * 32 + 32;  dx *= -1;
					}

					if (dy > 0) {
						rect1.top = i * 32 - rect1.height;
						dy = 0;
					}
					else if (dy < 0) {
						rect1.top = i * 32 + 32;
						dy*=-1;
					}

				}
	}

	//����
	void menu(RenderWindow& window) {
		Texture menuTexture1, menuTexture2, menuTexture3, aboutTexture, menuBackground; // �������� � �������� �������
		menuTexture1.loadFromFile("111.png");
		menuTexture2.loadFromFile("222.png");
		menuTexture3.loadFromFile("333.png");
		aboutTexture.loadFromFile("about.png");
		menuBackground.loadFromFile("sky.jpg");
		Sprite menu1(menuTexture1), menu2(menuTexture2), menu3(menuTexture3), about(aboutTexture), menuBg(menuBackground);
		bool isMenu = 1;
		int menuNum = 0;
		menu1.setPosition(100, 30);
		menu2.setPosition(100, 90);
		menu3.setPosition(100, 150);
		menuBg.setPosition(0, 0);
		menu1.setColor(Color::Green);
		menu2.setColor(Color::Green);
		menu3.setColor(Color::Green);


		while (isMenu)
		{
			menu1.setColor(Color::Black);
			menu2.setColor(Color::Black);
			menu3.setColor(Color::Black);
			menuNum = 0;
			window.clear(Color::Blue);

			if (IntRect(100, 30, 300, 50).contains(Mouse::getPosition(window))) { menu1.setColor(Color::Red); menuNum = 1; } // ��� �������, ����� ����� � ����������� ���������� ������
			if (IntRect(100, 90, 300, 50).contains(Mouse::getPosition(window))) { menu2.setColor(Color::Red); menuNum = 2; }
			if (IntRect(100, 150, 300, 50).contains(Mouse::getPosition(window))) { menu3.setColor(Color::Red); menuNum = 3; }

			if (Mouse::isButtonPressed(Mouse::Left))
			{
				if (menuNum == 1) isMenu = false;
				if (menuNum == 2) { window.draw(about); window.display(); while (!Keyboard::isKeyPressed(Keyboard::Escape)); }
				if (menuNum == 3) { window.close(); Logger::PrintLog("Game ended", LogErrType::INFO); exit(0); isMenu = false; }

			}

			window.draw(menuBg); //���������
			window.draw(menu1);
			window.draw(menu2);
			window.draw(menu3);

			window.display();
		}
	}

	player::player(Texture& image, Life& life) : life(life) {
		sprite.setTexture(image);
		sprite.setTextureRect(IntRect(0, 22, 16, 25));
		rect = FloatRect(1 * 32, 2 * 32, 16, 25);
		invulnerable = false;
		dx = dy = 0;
		currentFrame = 0;
	}

	void player::update(float time) {
		rect.left += dx * time;
		Collision(0);
		if (!onGround) {
			dy += 0.001 * time;
		}
		rect.top += dy * time;
		onGround = false;
		Collision(1);
		sprite.setPosition(rect.left - offsetX, rect.top - offsetY);

		if (invulnerable) {
			if (invulnerabilityTimer.getElapsedTime().asSeconds() >= 5) {
				invulnerable = false; // ��������� ���������� ����� 5 ������
			}
		}

		currentFrame += 0.007;
		if (currentFrame > 5) currentFrame -= 5;

		if (dx > 0) {
			sprite.setTextureRect(IntRect(17 * int(currentFrame), 211, 16, 25));
		}
		if (dx < 0) {
			sprite.setTextureRect(IntRect(17 * int(currentFrame) + 17, 211, -16, 25));
		}
		dx = 0;
	}

	void player::PlayerHP() {
		hp = 3;
	}

	void player::Collision(int dir)
	{
		for (int i = rect.top / 32; i < (rect.top + rect.height) / 32; i++)
			for (int j = rect.left / 32; j < (rect.left + rect.width) / 32; j++)
			{
				if (Map[i][j] == 'z' || Map[i][j] == 'x' || Map[i][j] == 'r' || Map[i][j] == 't' || Map[i][j] == 'c' || Map[i][j] == 'q' || Map[i][j] == 'w' || Map[i][j] == 'e')
				{
					if ((dx > 0) && (dir == 0))
						rect.left = j * 32 - rect.width;
					if ((dx < 0) && (dir == 0))
						rect.left = j * 32 + 32;
					if ((dy > 0) && (dir == 1)) {
						rect.top = i * 32 - rect.height;
						dy = 0;
						onGround = true;
					}
					if ((dy < 0) && (dir == 1)) {
						rect.top = i * 32 + 32;
						dy = 0;
					}
				}

				if (Map[i][j] == 'h' && hp < 3) {
					Logger::PrintLog("player healed", LogErrType::INFO);
					Map[i][j] = ' ';
					hp += 1;
					if (hp == 2) {
						life.s2.setTextureRect(IntRect(0, 0, 32, 32));
					}
					else if (hp == 3) {
						life.s3.setTextureRect(IntRect(0, 0, 32, 32));
					}
				}

				if (Map[i][j] == 'a' || Map[i][j] == 'h') {
					Map[i][j] = ' ';
				}

			}

	}

	

	
	// ����
	bool Game::Start() {

		Logger::SetLogLevel(LogLevel::DEBUG);
		Logger::SetLogPath("logs.txt");
		Logger::PrintLog("Game started", LogErrType::INFO);

		RenderWindow window(VideoMode(1280, 720), "Test!");

		Texture sky1Texture;
		sky1Texture.loadFromFile("sky1.png");
		Sprite sky1Sprite;
		sky1Sprite.setTexture(sky1Texture);
		sky1Sprite.setPosition(0, -300);

		menu(window);


		Image map_image;
		map_image.loadFromFile("map.png");
		Texture map;
		map.loadFromImage(map_image);
		Sprite s_map;
		s_map.setTexture(map);

		Texture p;
		p.loadFromFile("player.png");
		Texture h;
		h.loadFromFile("enemy.png");
		Life PlayerLife;
		player player(p, PlayerLife);
		player.PlayerHP();

		Logger::PrintLog("Texture loaded", LogErrType::INFO);

		vector<pepe> enemies; // ������ ������

		// ���������� ������ � ������
		pepe enemy1;
		enemy1.set(h, 22 * 32, 17 * 32);
		enemies.push_back(enemy1);

		pepe enemy2;
		enemy2.set(h, 35 * 32, 12 * 32);
		enemies.push_back(enemy2);

		Clock clock;

		RectangleShape rectangle(Vector2f(32, 32));


		while (window.isOpen())
		{
			
			float time = clock.getElapsedTime().asMicroseconds();
			clock.restart();

			time = time / 1000;

			Event event;
			while (window.pollEvent(event)) {
				if (event.type == Event::Closed) {
					Logger::PrintLog("Game ended", LogErrType::INFO);
					window.close();
				}
			}

			
			player.update(time);

			for (auto& enemy : enemies) {
				enemy.update(time);

				if (enemy.life && player.rect.intersects(enemy.rect1)) {
					Logger::PrintLog("Player intersect with enemy", LogErrType::INFO);
					if (player.dy > 0) {
						Logger::PrintLog("Player kill enemy", LogErrType::INFO);
						enemy.life = false;
						player.dy = -0.5;
					}

					if (player.dy == 0 && player.invulnerable == false) {
						if (player.hp == 1) {
							player.sprite.setColor(Color::Red);
							Logger::PrintLog("player dead", LogErrType::INFO);
							window.close();
						}
						else if (player.hp == 3 && player.invulnerable == false) {
							player.hp -= 1;
							PlayerLife.s3.setTextureRect(IntRect(0, 0, 0, 0));
						}
						else if (player.hp == 2 && player.invulnerable == false) {
							player.hp -= 1;
							PlayerLife.s2.setTextureRect(IntRect(0, 0, 0, 0));
						}

						player.invulnerable = true; // �������� ����������
						player.invulnerabilityTimer.restart(); // ��������� ������ ����������
					}
				}
			}


			
			sf::View view(sf::FloatRect(0, 0, 1280, 720));
			view.zoom(0.6); 
			view.setCenter(player.rect.left + player.rect.width / 2, player.rect.top + player.rect.height / 2);

			// ��������� ������� ����� � ��������� ��������� ������
			if (view.getCenter().x - view.getSize().x / 2 < 0)
			{
				view.setCenter(view.getSize().x / 2, view.getCenter().y);
			}
			else if (view.getCenter().x + view.getSize().x / 2 > W * 32)
			{
				view.setCenter(W * 32 - view.getSize().x / 2, view.getCenter().y);
			}

			if (view.getCenter().y - view.getSize().y / 2 < 0)
			{
				view.setCenter(view.getCenter().x, view.getSize().y / 2);
			}
			else if (view.getCenter().y + view.getSize().y / 2 > H * 32)
			{
				view.setCenter(view.getCenter().x, H * 32 - view.getSize().y / 2);
			}

			window.setView(view);

			if (Keyboard::isKeyPressed(Keyboard::Left)) {
				player.dx = -0.1;
			}
			if (Keyboard::isKeyPressed(Keyboard::Right)) {
				player.dx = 0.1;
			}
			if (Keyboard::isKeyPressed(Keyboard::Up)) {
				if (player.onGround) {
					player.dy = -0.37;
					player.onGround = false;
				}
			}

			if (Keyboard::isKeyPressed(Keyboard::Tab))  return true; //���� ���, �� ������������� ����
			if (Keyboard::isKeyPressed(Keyboard::Escape)) { Logger::PrintLog("Game ended", LogErrType::INFO); return false; } //���� ������, �� ������� �� ����

			if (player.rect.left < 0 || player.rect.left + player.rect.width > W * 32 ||
				player.rect.top < 0 || player.rect.top + player.rect.height > H * 32)
			{
				player.rect.left = max(0.f, min(player.rect.left, (W * 32) - player.rect.width));
				player.rect.top = max(0.f, min(player.rect.top, (H * 32) - player.rect.height));
			}

			window.clear(Color::White);
			window.draw(sky1Sprite);

			for (int i = 0; i < H; i++) {
				for (int j = 0; j < W; j++)
				{
					if (Map[i][j] == 'l') {
						s_map.setTextureRect(IntRect(2, 96, 32, 32));
					}

					if (Map[i][j] == 'k') {
						s_map.setTextureRect(IntRect(32, 96, 32, 32));
					}

					if (Map[i][j] == 'e') {
						s_map.setTextureRect(IntRect(64, 96, 32, 32));
					}

					if (Map[i][j] == 'm') {
						s_map.setTextureRect(IntRect(2, 64, 32, 32));
					}

					if (Map[i][j] == 'n') {
						s_map.setTextureRect(IntRect(32, 64, 32, 32));
					}

					if (Map[i][j] == 'w') {
						s_map.setTextureRect(IntRect(64, 64, 32, 32));
					}

					if (Map[i][j] == 'r') {
						s_map.setTextureRect(IntRect(0, 32, 32, 32));
					}

					if (Map[i][j] == 't') {
						s_map.setTextureRect(IntRect(32, 32, 32, 32));
					}

					if (Map[i][j] == 'q') {
						s_map.setTextureRect(IntRect(64, 32, 32, 32));
					}

					if (Map[i][j] == 'g') {
						s_map.setTextureRect(IntRect(0, 0, 32, 32));
					}

					if (Map[i][j] == '>') {
						s_map.setTextureRect(IntRect(128, 0, 32, 32));
					}

					if (Map[i][j] == 'o') {
						s_map.setTextureRect(IntRect(64, 0, 32, 32));
					}

					if (Map[i][j] == 'i') {
						s_map.setTextureRect(IntRect(192, 0, 32, 32));
					}

					if (Map[i][j] == 'z') {
						s_map.setTextureRect(IntRect(128, 32, 32, 32));
					}

					if (Map[i][j] == 'x') {
						s_map.setTextureRect(IntRect(160, 32, 32, 32));
					}

					if (Map[i][j] == 'c') {
						s_map.setTextureRect(IntRect(192, 32, 32, 32));
					}

					if (Map[i][j] == 'a') {
						s_map.setTextureRect(IntRect(96, 0, 32, 32));
					}


					if (Map[i][j] == 'h') {
						s_map.setTextureRect(IntRect(256, 0, 32, 32));
					}

					if (Map[i][j] == ' ') continue;

					s_map.setPosition(j * 32, i * 32);

					window.draw(s_map);
				}
			}

			PlayerLife.draw(window);
			window.draw(player.sprite);
			for (const auto& enemy : enemies) {
				window.draw(enemy.sprite1);
			}
			window.display();
		}
	}

	void Game::Run() {
		if (Game::Start()) {
			Run();
		}
		else exit(0);
	}
};