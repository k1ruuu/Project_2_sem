#pragma once
#include <SFML/Graphics.hpp>
#include <iostream>
#include "lab6.hpp"
#include <vector>
#include <list>

using namespace std;
using namespace sf;

namespace ss {

	void menu(RenderWindow& window);

	class Game {
	public:
		bool Start();
		void Run();
	};

	class Enemy
	{
	public:
		float dx, dy;
		FloatRect rect1;
		Sprite sprite1;
		float currentFrame1;
		bool life;
		virtual void update(float time);

		virtual void set(Texture& image, int x, int y);
		virtual void Collision();

	private:
	};

	class pepe : public Enemy {
	public:
		void set(Texture& image, int x, int y) override;
		void update(float time) override;
		void Collision() override;
	};

	class Life
	{
	public:
		Image image;
		Texture t;
		Sprite s1;
		Sprite s2;
		Sprite s3;
		int hp;

		Life();

		void draw(RenderWindow& window);

	};


	class player {
	public:
		int hp;
		float dx, dy;
		FloatRect rect;
		bool onGround;
		Sprite sprite;
		float currentFrame;
		bool invulnerable;
		Clock invulnerabilityTimer;
		Life& life;

		player(Texture& image, Life& life);

		void PlayerHP();

		void update(float time);
		void Collision(int dir);
	};

	
}