﻿#include <SFML/Graphics.hpp>
#include <iostream>
#include "Game.hpp"
#include "lab6.hpp"
#include <vector>
#include <list>

using namespace sf;

int main()
{
	ss::Game game;
	game.Run();

	return 0;
}